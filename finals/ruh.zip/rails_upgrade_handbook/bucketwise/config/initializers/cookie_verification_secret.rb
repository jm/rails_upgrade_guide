# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '00e729e8356731c2cd98a409498ddc73a062984beddd2c6028a6538e6b06f6efd155fac22435dca0dc659ad15e3110798176d10ef06098191b086b1b38fc06fb'
