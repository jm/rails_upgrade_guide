class ApplicationController < ActionController::Base
  include AuthenticatedSystem
  protect_from_forgery
  
  def check_logged_in
    redirect_to pages_path if logged_in?
  end
end
