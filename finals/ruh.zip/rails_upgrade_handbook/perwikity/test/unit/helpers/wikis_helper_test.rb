require 'test_helper'

class WikisHelperTest < ActionView::TestCase
end
