Perwikity::Application.routes.draw do
  resources :pages do
    member do
      post :revert
      get :revisions
    end
  end

  match '/logout' => 'sessions#destroy', :as => :logout
  match '/login' => 'sessions#new', :as => :login
  match '/register' => 'users#create', :as => :register
  match '/signup' => 'users#new', :as => :signup

  resources :users
  resource :session

  root :to => 'pages#show'
end
