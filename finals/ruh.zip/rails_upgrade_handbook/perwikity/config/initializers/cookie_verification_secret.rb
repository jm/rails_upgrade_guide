# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'c1226ff968811e969a1e107de5eb0e42033c324bcb6ee3ab8d09d00121920bf187e5d5c379c102da1eb20cc0e56cdeac8476a9a9f17d5d39e26173ad8b4f72cb'
