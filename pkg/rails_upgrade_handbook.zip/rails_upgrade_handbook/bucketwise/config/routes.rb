Bucketwise::Application.routes.draw do
  resource :session
  
  resources :subscriptions do
    resources :accounts, :events, :tags
  end
  
  resources :events

  resources :buckets do
    resources :events
  end
  
  resources :accounts do
    resources :buckets, :events, :statements
  end
  
  resources :tags do
    resources :events
  end
  
  resources :tagged_items
  resources :statements
  
  root :to => "subscriptions#index"
end
